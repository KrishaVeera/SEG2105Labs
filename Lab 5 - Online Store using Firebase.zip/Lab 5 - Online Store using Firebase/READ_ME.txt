Name: Krisha Veera 
Student Number: 300291136
Github: https://github.com/SEG2105BC-uOttawa/seg2105-f23-lab6-KrishaVeera.git 
